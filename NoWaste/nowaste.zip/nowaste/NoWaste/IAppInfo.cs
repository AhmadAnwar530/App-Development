﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NoWaste
{
  public interface IAppInfo
  {
    string GetAppVersion();
    string GetSystemInfo();

  }
}
