﻿using NoWaste.Domain.Models.Aggregates;
using NoWaste.Enums;
using NoWaste.Models;
using NoWaste.View.Settings;
using NoWaste.View.Sort;
using NoWaste.ViewModels;
using Rg.Plugins.Popup.Services;
using System;
using Xamarin.Forms;

namespace NoWaste
{
    public partial class NoWasteMainPage : ContentPage
    {
        public MainPageViewModel VM;

        public NoWasteMainPage()
        {
            //NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
            VM = new MainPageViewModel();
            BindingContext = VM;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            VM.LoadItems();

        }

        async void OnCancelClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        void listView_ItemTapped(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            Navigation.PushAsync(new NoWasteAddItem((ItemModel)e.Item));
        }

        void ToolbarItem_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new NoWasteAddItem());
        }

        void Filter_Clicked(System.Object sender, System.EventArgs e)
        {
            search.IsVisible = !search.IsVisible;
            VM.SearchText = string.Empty;
        }

        void Sort_Clicked(System.Object sender, System.EventArgs e)
        {
            var popup = new SortPopup();
            popup.Apply += ApplySort;
            PopupNavigation.Instance.PushAsync(popup);
        }

        void ApplySort(SortEnum sortEnum)
        {
            VM.ApplySort(sortEnum);
        }

        void SettingItem_Clicked(System.Object sender, System.EventArgs e)
        {
            var settingsPopup = new SettingsPopup();
            settingsPopup.SettingChanged += (IsShowExpiry) => { VM.LoadItems(IsShowExpiry); };
            PopupNavigation.Instance.PushAsync(settingsPopup);
        }

        void Name_Tapped(System.Object sender, System.EventArgs e)
        {
            var sort = VM.ShowNameDesc ? SortEnum.NameDescending : SortEnum.NameAscending;
            ApplySort(sort);
            VM.ShowHideArrows(sort);
        }

        void Category_Tapped(System.Object sender, System.EventArgs e)
        {
            var sort = VM.ShowCategoryDesc ? SortEnum.CategoryDescending : SortEnum.CategoryAscending;
            ApplySort(sort);
            VM.ShowHideArrows(sort);
        }

        void Expiry_Tapped(System.Object sender, System.EventArgs e)
        {
            var sort = !VM.ShowExpiryDesc? SortEnum.ExpiryAscending: SortEnum.ExpiryDescending;
            ApplySort(sort);
            VM.ShowHideArrows(sort);
        }
    }
}